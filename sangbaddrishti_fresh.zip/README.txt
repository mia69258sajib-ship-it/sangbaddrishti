সংবাদদৃষ্টি — প্রাথমিক স্ট্যাটিক ওয়েবসাইট

GitHub Pages-এ প্রকাশের জন্য:
1. ZIP ফাইলটি Extract করুন।
2. index.html, style.css, script.js এবং README.txt ফাইলগুলো Repository-এর root-এ আপলোড করুন।
3. Repository > Settings > Pages > Deploy from a branch নির্বাচন করুন।
4. Branch: main এবং Folder: /(root) নির্বাচন করে Save চাপুন।

নোট: ওয়েবসাইটে থাকা খবরগুলো নমুনা কনটেন্ট; বাস্তব সংবাদ নয়। প্রকাশের আগে যাচাই করা সংবাদ ও প্রয়োজনীয় যোগাযোগের তথ্য যোগ করুন।
