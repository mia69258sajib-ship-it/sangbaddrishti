const menuBtn = document.getElementById("menuBtn");
const nav = document.getElementById("nav");
menuBtn?.addEventListener("click", () => nav.classList.toggle("open"));

const now = new Date();
document.getElementById("year").textContent = now.getFullYear();
document.getElementById("today").textContent = new Intl.DateTimeFormat("bn-BD", {
  weekday: "long", year: "numeric", month: "long", day: "numeric"
}).format(now);

const form = document.getElementById("searchForm");
const input = document.getElementById("searchInput");
const noResults = document.getElementById("noResults");
form.addEventListener("submit", (event) => {
  event.preventDefault();
  const query = input.value.trim().toLocaleLowerCase("bn");
  let shown = 0;
  document.querySelectorAll(".story").forEach((story) => {
    const match = !query || story.innerText.toLocaleLowerCase("bn").includes(query);
    story.hidden = !match;
    if (match) shown++;
  });
  noResults.hidden = shown > 0;
});
input.addEventListener("input", () => {
  if (!input.value.trim()) {
    document.querySelectorAll(".story").forEach((story) => story.hidden = false);
    noResults.hidden = true;
  }
});
